package com.bjsxt.mapper;

import com.bjsxt.pojo.BusChecks;

public interface BusChecksMapper {
    //添加车辆检查数据
    public int insertBusChecks(BusChecks busChecks);
}
