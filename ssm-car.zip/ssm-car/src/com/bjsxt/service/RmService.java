package com.bjsxt.service;

import java.util.List;

public interface RmService {
    //查询mid
    public List<Integer> findMid(int rid);
}
